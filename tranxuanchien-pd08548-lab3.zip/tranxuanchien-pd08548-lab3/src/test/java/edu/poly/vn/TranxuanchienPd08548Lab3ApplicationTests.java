package edu.poly.vn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranxuanchienPd08548Lab3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
