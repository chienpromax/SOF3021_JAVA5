package edu.poly.vn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranxuanchienPd08548Lab3Application {

	public static void main(String[] args) {
		SpringApplication.run(TranxuanchienPd08548Lab3Application.class, args);
	}
	
}
