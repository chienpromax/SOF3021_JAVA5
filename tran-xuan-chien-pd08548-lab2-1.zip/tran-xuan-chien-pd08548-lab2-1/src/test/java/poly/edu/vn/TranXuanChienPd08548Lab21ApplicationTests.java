package poly.edu.vn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranXuanChienPd08548Lab21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
