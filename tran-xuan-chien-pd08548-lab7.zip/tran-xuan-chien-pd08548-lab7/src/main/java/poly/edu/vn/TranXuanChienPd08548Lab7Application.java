package poly.edu.vn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranXuanChienPd08548Lab7Application {

	public static void main(String[] args) {
		SpringApplication.run(TranXuanChienPd08548Lab7Application.class, args);
	}

}
